package com.example.BootArasuDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class BootArasuDemoApplication {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(BootArasuDemoApplication.class, args);
		TestBoot obj=(TestBoot)ac.getBean("t");
		obj.m();
	}

}
