package com.example.BootArasuDemo;

import org.springframework.stereotype.Component;

@Component("t")
public class TestBoot {
	
	void m(){
		System.out.println("STARTED APPLICATIOn!!!!");
	}

}
